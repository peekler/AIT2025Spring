//
//  iOSAITDemoApp.swift
//  iOSAITDemo
//
//  Created by Peter Ekler on 2025. 05. 07..
//

import SwiftUI

@main
struct iOSAITDemoApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            BMIView()
        }
    }
}
