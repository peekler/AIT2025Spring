//
//  iOSAITDemoTests.swift
//  iOSAITDemoTests
//
//  Created by Peter Ekler on 2025. 05. 07..
//

import Testing
@testable import iOSAITDemo

struct iOSAITDemoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
