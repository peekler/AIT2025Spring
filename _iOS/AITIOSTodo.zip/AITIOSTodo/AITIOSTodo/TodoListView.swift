//
//  TodoListView.swift
//  AITIOSTodo
//
//  Created by Peter Ekler on 10/05/2024.
//

import SwiftUI


struct TodoListView: View {
    @State private var showingAlert = false
    
    @StateObject var viewModel: ViewModel
    
    var body: some View {
        List {
            ForEach(viewModel.todos) { todo in
                TodoItemView(todo: todo)
            }
            .onDelete(perform: viewModel.delete)
        }
        .listRowInsets(.none)
        .listStyle(.plain)
        .alert("Add Todo", isPresented: $showingAlert) {
            TextField("Enter todo description", text: $viewModel.todoName)
                .autocorrectionDisabled(true)
            Button("Add") {
                viewModel.addTodo()
                showingAlert.toggle()
            }
            Button("Cancel")
            {
                viewModel.todoName = ""
                showingAlert.toggle()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showingAlert.toggle()
                } label: {
                    Text("Add")
                }
            }
        }
    }
}
