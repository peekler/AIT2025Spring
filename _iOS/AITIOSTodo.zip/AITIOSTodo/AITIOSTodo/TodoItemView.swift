//
//  TodoItemView.swift
//  AITIOSTodo
//
//  Created by Peter Ekler on 10/05/2024.
//

import SwiftUI

struct TodoItemView: View {

    @State var todo: TodoItem
    @State private var isChecked = false
    var body: some View {
        HStack {
            Text(todo.name)
            Spacer()
            Toggle("", isOn: $todo.isChecked)
        }
        .padding(.horizontal)
        .padding(.vertical, 5)
        .onChange(of: isChecked) { newValue in
            todo.isChecked = newValue
        }
    }

    init(todo: TodoItem) {
        self.todo = todo
    }
}

