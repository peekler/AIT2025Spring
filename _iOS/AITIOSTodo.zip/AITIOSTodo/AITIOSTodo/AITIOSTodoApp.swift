//
//  AITIOSTodoApp.swift
//  AITIOSTodo
//
//  Created by Peter Ekler on 10/05/2024.
//

import SwiftUI

@main
struct AITIOSTodoApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                TodoListView(viewModel: TodoListView.ViewModel(todos: []))
            }
        }
    }
}
