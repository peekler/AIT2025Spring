//
//  iOSTimeShowApp.swift
//  iOSTimeShow
//
//  Created by Peter Ekler on 2025. 02. 10..
//

import SwiftUI

@main
struct iOSTimeShowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
